<script setup lang="ts">
const props = defineProps<{ slug: string }>();
const vote = useCookie<"yes" | "no" | null>(`workflow-article-vote-${props.slug}`, { default: () => null, sameSite: "lax", maxAge: 30 * 86400 });
</script>
<template>
  <div class="article-feedback">
    <h3>Была ли статья полезна?</h3>
    <div class="feedback-buttons"><button class="button button-secondary" :aria-pressed="vote === 'yes'" @click="vote = 'yes'">Да</button><button class="button button-secondary" :aria-pressed="vote === 'no'" @click="vote = 'no'">Нет</button></div>
    <p v-if="vote" class="field-hint" role="status">Спасибо за ответ.</p>
  </div>
</template>
